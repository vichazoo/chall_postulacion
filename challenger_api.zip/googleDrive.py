from operator import contains
from turtle import title
from pydrive2.auth import GoogleAuth 
from pydrive2.drive import GoogleDrive
from crypt import methods
import json
from flask import Flask, jsonify,request

directorio_credenciales =  'credentials_module.json'

# iniciar sesion
def login():
        gauth = GoogleAuth()
        gauth.LoadCredentialsFile(directorio_credenciales)

        if gauth.access_token_expired:
            gauth.Refresh()
            gauth.SaveCredentialsFile(directorio_credenciales)
        else:
            gauth.Authorize()

        gauth.SaveCredentialsFile(directorio_credenciales)
        Credenciales = GoogleDrive(gauth)
        return Credenciales

app = Flask(__name__)

#prueba
@app.route('/pnp', methods=['GET'])
def pnp():
    return jsonify({"message": "pong!"})

def buscar(querry):
    resultado = []
    credenciales = login()
    querry = contains

    



#crear archivo de text__prueba
#def crear_archivo_texto(nombre_archivo,contenido,id_folder):
#    credenciales = login()
#    archivo = credenciales.CreateFile({'titulo': nombre_archivo,
#                                        'parents': [{'kind': 'drive#fileLink', 'id': id_folder}]})
#    archivo.SetContentString(contenido)
#    archivo.Upload()



if __name__ == "__main__":
    login()
    app.run(debug=True, port=8080) 
 #   crear_archivo_texto('prueba.txt', 'hello clvl', '1xR4VhhmyL6gW8o_nIOPKJx0lq9lC2emv')



